﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StudentSpec
{
    [Serializable]
    public class Student
    {
        //номер студента в бд
        public int id { get; set; }
        public string fio { get; set; }
        public DateTime birthday { get; set; }
        //дата создания записи в бд
        public DateTime createDate { get; set; }
        //паспортные данные
        public string pasport { get; set; }
        //группа
        public int gr { get; set; }
        //специальносить
        public int special { get; set; }

        public Student()
        {

        }

        //конструктор для сериализации
        public Student(SerializationInfo sInfo, StreamingContext contextArg)
        {
            this.id = (int)sInfo.GetValue("id", typeof(int));
            this.fio = (string)sInfo.GetValue("fio", typeof(string));
            this.birthday = (DateTime)sInfo.GetValue("birthday", typeof(DateTime));
            this.createDate = (DateTime)sInfo.GetValue("createDate", typeof(DateTime));
            this.pasport = (string)sInfo.GetValue("pasport", typeof(string));
            this.gr = (int)sInfo.GetValue("gr", typeof(int));
            this.special = (int)sInfo.GetValue("special", typeof(int));
        }

        //получение данных для сериализации
        public void GetObjectData(SerializationInfo sInfo, StreamingContext contextArg)
        {
            sInfo.AddValue("id", this.id);
            sInfo.AddValue("fio", this.fio);
            sInfo.AddValue("birthday", this.birthday);
            sInfo.AddValue("createDate", this.createDate);
            sInfo.AddValue("pasport", this.pasport);
            sInfo.AddValue("gr", this.gr);
            sInfo.AddValue("special", this.special);
        }
    }
}
