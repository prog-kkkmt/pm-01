﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentSpec
{
    public partial class Form1 : Form
    {
        SQL sql;    //класс работы с sqlite
        int currentSpecial = 0; //id выбранной пользователем специальности
        int currentGr = 0;      //id выбранной группы
        int currentStudent = 0; //id выбранного студента

        List<Special> listSpecials; //список специальснотей
        List<Groups> listGr;        //список групп для выбранной специальности
        int currentSpecialInd = 0;  //номер выбранной специальности в списке
        int currentGrInd = 0;       //номер выбранной группы в списке
        List<Groups> listGrTemp;        //список групп, используется для перевода студента на др. специальность/группу
        Dictionary<string, int> graphic = null; //для вывода графика, хранит пары: наименование группы - количество студентов
        List<Color> colors; //список цветов для отображения колонок в графике
        

        public Form1()
        {
            InitializeComponent();

            //подключаемся к бд
            sql = new SQL();
            sql.createScheme();

            //загружаем список специальснотей
            updateSpecial();
        }

        private void buttonAddSpec_Click(object sender, EventArgs e)
        {
            sql.addSpecial(textBoxSpecName.Text, textBoxSpecDescr.Text);
            updateSpecial();
        }

        public void updateSpecial()
        {
            listSpecials = sql.getListSpecial();
            dataGridViewSpecial.Rows.Clear();
            dataGridViewSpecial.RowCount = listSpecials.Count;
            comboBoxSpecial.Items.Clear();

            for (int i = 0; i < listSpecials.Count; i++)
            {
                dataGridViewSpecial.Rows[i].Cells[0].Value = listSpecials[i].id;
                dataGridViewSpecial.Rows[i].Cells[1].Value = listSpecials[i].name;
                dataGridViewSpecial.Rows[i].Cells[2].Value = listSpecials[i].descr;
                dataGridViewSpecial.Rows[i].Cells[3].Value = "Открыть";
                dataGridViewSpecial.Rows[i].Cells[4].Value = "Удалить";

                comboBoxSpecial.Items.Add(listSpecials[i].name);
            }
        }

        public void updateGr(int special)
        {
            listGr = sql.getListGr(special);
            dataGridViewGr.Rows.Clear();
            dataGridViewGr.RowCount = listGr.Count;

            comboBoxGr.Items.Clear();


            for (int i = 0; i < listGr.Count; i++)
            {
                dataGridViewGr.Rows[i].Cells[0].Value = listGr[i].id;
                dataGridViewGr.Rows[i].Cells[1].Value = listGr[i].name;
                dataGridViewGr.Rows[i].Cells[2].Value = listGr[i].students;
                dataGridViewGr.Rows[i].Cells[3].Value = "Открыть";
                dataGridViewGr.Rows[i].Cells[4].Value = "Удалить";

                comboBoxGr.Items.Add(listGr[i].name);
            }
        }

        //перевод даты в строку для вывода пользователю
        private string dateToStr(DateTime dt)
        {
            string res;
            if (dt.Day < 10)
                res = "0" + dt.Day + ".";
            else
                res = dt.Day + ".";

            if (dt.Month < 10)
                res += "0" + dt.Month + ".";
            else
                res += dt.Month + ".";

            res += dt.Year;

            return res;
        }

        public void updateStudents(int gr)
        {
            List<Student> list = sql.getListStudents(gr, currentSpecial);
            dataGridViewStudents.Rows.Clear();
            dataGridViewStudents.RowCount = list.Count;

            for (int i = 0; i < list.Count; i++)
            {
                dataGridViewStudents.Rows[i].Cells[0].Value = list[i].id;
                dataGridViewStudents.Rows[i].Cells[1].Value = list[i].fio;
                dataGridViewStudents.Rows[i].Cells[2].Value = dateToStr(list[i].birthday);
                dataGridViewStudents.Rows[i].Cells[3].Value = list[i].pasport;
                dataGridViewStudents.Rows[i].Cells[4].Value = list[i].createDate;
                dataGridViewStudents.Rows[i].Cells[5].Value = "Открыть";
            }

        }

        private void dataGridViewSpecial_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            sql.editSpecial((int)dataGridViewSpecial.Rows[e.RowIndex].Cells[0].Value, 
                    (string)dataGridViewSpecial.Rows[e.RowIndex].Cells[1].Value,
                    (string)dataGridViewSpecial.Rows[e.RowIndex].Cells[2].Value);
        }

        //клик по кнопкам в таблице специальностей
        private void dataGridViewSpecial_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex==3)
            {
                //открыть
                tabControl1.SelectedIndex = 1;
                labelSpecial.Text = (string)dataGridViewSpecial.Rows[e.RowIndex].Cells[1].Value;
                currentSpecial = (int)dataGridViewSpecial.Rows[e.RowIndex].Cells[0].Value;
                currentSpecialInd = e.RowIndex;

                updateGr(currentSpecial);

                comboBoxSpecial.SelectedIndex = e.RowIndex;
            }
            else if (e.ColumnIndex == 4)
            {
                //удалить
                sql.deleteSpecial((int)dataGridViewSpecial.Rows[e.RowIndex].Cells[0].Value);
                updateGr(currentSpecial);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void buttonAddGroup_Click(object sender, EventArgs e)
        {
            sql.addGroup(textBoxGroup.Text, currentSpecial);
            updateGr(currentSpecial);
        }

        private void dataGridViewGr_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            sql.editGr((int)dataGridViewGr.Rows[e.RowIndex].Cells[0].Value,
                    (string)dataGridViewGr.Rows[e.RowIndex].Cells[1].Value);
        }

        private void buttonAddStudent_Click(object sender, EventArgs e)
        {
            int id = sql.addStudent(textBoxFIO.Text, dateTimePickerBirthday.Value, textBoxPasport.Text);
            sql.addStudentSpec(id, currentGr);
            updateStudents(currentGr);
        }

        private void dataGridViewGr_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                //открыть
                tabControl1.SelectedIndex = 2;
                labelSpecGr.Text = labelSpecial.Text + "   " + (string)dataGridViewGr.Rows[e.RowIndex].Cells[1].Value;
                currentGr = (int)dataGridViewGr.Rows[e.RowIndex].Cells[0].Value;
                currentGrInd = e.RowIndex;
                updateStudents(currentGr);

                comboBoxGr.SelectedIndex = e.RowIndex;
            }
            else if (e.ColumnIndex == 4)
            {
                //удалить
                sql.deleteGr((int)dataGridViewGr.Rows[e.RowIndex].Cells[0].Value);
                updateStudents(currentGr);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            sql.close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
            updateGr(currentGr);
        }

        private void dataGridViewStudents_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DateTime dt;

            if (dataGridViewStudents.Rows[e.RowIndex].Cells[2].Value is DateTime)
                dt = (DateTime)dataGridViewStudents.Rows[e.RowIndex].Cells[2].Value;
            else
            {
                string str = (string)dataGridViewStudents.Rows[e.RowIndex].Cells[2].Value;
                dt = DateTime.Parse(str);
            }

            sql.editStudent((int)dataGridViewStudents.Rows[e.RowIndex].Cells[0].Value,
                    (string)dataGridViewStudents.Rows[e.RowIndex].Cells[1].Value,
                    dt,
                    (string)dataGridViewStudents.Rows[e.RowIndex].Cells[3].Value);
        }

        private void dataGridViewStudents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 5)
            {
                //открыть
                tabControl1.SelectedIndex = 3;
                currentStudent = (int)dataGridViewStudents.Rows[e.RowIndex].Cells[0].Value;
                textBoxDetailFIO.Text = (string)dataGridViewStudents.Rows[e.RowIndex].Cells[1].Value;
                textBoxDetailPassport.Text = (string)dataGridViewStudents.Rows[e.RowIndex].Cells[3].Value;
                
                updateStudentInfo();
            }            
        }

        public void updateStudentInfo()
        {
            comboBoxGr.Items.Clear();

            for (int i = 0; i < listGr.Count; i++)
            {                
                comboBoxGr.Items.Add(listGr[i].name);
            }

            comboBoxGr.SelectedIndex = currentGrInd;
        }

        private void comboBoxSpecial_SelectedIndexChanged(object sender, EventArgs e)
        {
            listGrTemp = sql.getListGr(listSpecials[comboBoxSpecial.SelectedIndex].id);
                   
            comboBoxGr.Items.Clear();

            for (int i = 0; i < listGrTemp.Count; i++)
            {
                comboBoxGr.Items.Add(listGrTemp[i].name);
            }
        }

        
        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
            updateStudents(currentGr);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sql.deleteStudent(currentStudent);
            button3_Click(this, null);
        }

        private void buttonStudentSpecSet_Click(object sender, EventArgs e)
        {
            sql.setStudentSpec(currentStudent, listGrTemp[comboBoxGr.SelectedIndex].id);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            string ReadResFilePlace = null; 
            //разрешение файлов
            saveFileDialog1.Filter = "(*.xml)|*.xml|All files (*.*)|*.*";
            //имя файла по умолчнию
            saveFileDialog1.FileName = "database";
            saveFileDialog1.DefaultExt = "xml";
            //показываем диалог сохранения
            DialogResult drs = saveFileDialog1.ShowDialog();
            ReadResFilePlace = saveFileDialog1.FileName;

            
            if (ReadResFilePlace != String.Empty)
            {
                SpecialsList sl = new SpecialsList();
                sl.list = sql.getListSpecial();
                for (int i = 0; i < sl.list.Count; i++)
                {
                    sl.list[i].groups = sql.getListGr(sl.list[i].id);
                    for (int j = 0; j < sl.list[i].groups.Count; j++)
                    {
                        sl.list[i].groups[j].list = sql.getListStudents(sl.list[i].groups[j].id, sl.list[i].id);
                    }
                }

                SpecialsList.SerializeObject(ReadResFilePlace, sl);
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            string ReadResFilePlace = null; 
            //разрешение файлов
            saveFileDialog1.Filter = "(*.pdf)|*.pdf|All files (*.*)|*.*";
            //имя файла по умолчнию
            saveFileDialog1.FileName = "report";
            saveFileDialog1.DefaultExt = "pdf";
            //показываем диалог сохранения
            DialogResult drs = saveFileDialog1.ShowDialog();
            ReadResFilePlace = saveFileDialog1.FileName;


            if (ReadResFilePlace != String.Empty)
            {
                SpecialsList sl = new SpecialsList();
                sl.list = sql.getListSpecial();
                string text = "";

                PdfDocument pdf = new PdfDocument();

                XPdfFontOptions options = new XPdfFontOptions(PdfFontEncoding.Unicode, PdfFontEmbedding.Always);

                pdf.Info.Title = "Количество студентов на специальностях";
                PdfPage pdfPage = pdf.AddPage();
                XGraphics graph = XGraphics.FromPdfPage(pdfPage);
                XFont font = new XFont("Verdana", 14, XFontStyle.Regular, options);

                for (int i = 0; i < sl.list.Count; i++)
                {
                    int num = 0;
                    sl.list[i].groups = sql.getListGr(sl.list[i].id);
                    for (int j = 0; j < sl.list[i].groups.Count; j++)
                    {
                        num += sl.list[i].groups[j].students;
                    }

                    graph.DrawString( "    " + (i+1) + ") " + 
                        sl.list[i].name + " - " + num, font,
                        XBrushes.Black,
                        new XRect(0, 50 + i*20, pdfPage.Width.Point, pdfPage.Height.Point),
                            XStringFormats.TopLeft);
                }
                                

                pdf.Save(ReadResFilePlace);
                Process.Start(ReadResFilePlace);
            }

            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            graphic = new Dictionary<string, int>();

            SpecialsList sl = new SpecialsList();
            sl.list = sql.getListSpecial();

            colors = new List<Color>(); //создаем список цетов
            Random r = new Random();

            for (int i = 0; i < sl.list.Count; i++)
            {
                sl.list[i].groups = sql.getListGr(sl.list[i].id);
                for (int j = 0; j < sl.list[i].groups.Count; j++)
                {
                    //вносим значение
                    graphic.Add(sl.list[i].groups[j].name, sl.list[i].groups[j].students);
                    //цвета определяются случайно, но выбираются светлые тона, чтобы были видны надписи на них
                    colors.Add(Color.FromArgb(100 + r.Next(155), 100 + r.Next(155), 100 + r.Next(155)));
                }
            }

            //переходим на вкладку с графиком
            tabControl1.SelectedIndex = 4;
            //вызываем перерисовку формы
            Invalidate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            //если нет данных, выходим
            if (graphic == null)
                return;
            
            //ищем максимальное количесто студентов
            int maxStudent = 0;
            foreach (KeyValuePair<string, int> pair in graphic)
            {
                if (pair.Value > maxStudent)
                    maxStudent = pair.Value;
            }

            //высота прямоугольников
            int rectHeight = (panel1.Height - 100) / graphic.Count;
            //коэфициент длины прямоугольников
            int kWidth = (panel1.Width - 100)/maxStudent;

            Graphics gr = e.Graphics;

            
            int i = 0;
            foreach (KeyValuePair<string, int> pair in graphic)
            {
                SolidBrush myBrush = new SolidBrush(colors[i]);

                gr.FillRectangle(myBrush, 50, 30 + i * rectHeight, kWidth * pair.Value, rectHeight);
                gr.DrawString(pair.Key, Font, Brushes.Black, new PointF(60, 32 + i * rectHeight));
                
                i++;
            }

            //выводим оси
            gr.DrawLine(Pens.Black, 50, 20, 50, 30 + i * rectHeight);
            gr.DrawLine(Pens.Black, 50, 30 + i * rectHeight, panel1.Width-30, 30 + i * rectHeight);

            //выводим цифры
            for (int j=0; j<=5; j++)
            {
                gr.DrawString((j * maxStudent/5.0f) + "", Font, Brushes.Black, new PointF(50+j * (panel1.Width - 100) / 5, 32 + i * rectHeight));
            }
        }

        
    }
}
