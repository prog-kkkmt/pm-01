﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StudentSpec
{
    [Serializable]
    public class Special
    {
        //номер специальности
        public int id {get; set;}
        //наименование специальности
        public string name { get; set; }
        //описание
        public string descr { get; set; }
        //список групп на этой специальности
        public List<Groups> groups;

        public Special()
        {

        }

        public Special(SerializationInfo sInfo, StreamingContext contextArg)
        {
            this.id = (int)sInfo.GetValue("id", typeof(int));
            this.name = (string)sInfo.GetValue("name", typeof(string));
            this.descr = (string)sInfo.GetValue("descr", typeof(string));
            this.groups = (List<Groups>)sInfo.GetValue("groups", typeof(List<Groups>));
        }

        public void GetObjectData(SerializationInfo sInfo, StreamingContext contextArg)
        {
            sInfo.AddValue("id", this.id);
            sInfo.AddValue("name", this.name);
            sInfo.AddValue("descr", this.descr);
            sInfo.AddValue("groups", this.groups);
        }


    }
}
