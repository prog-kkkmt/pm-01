﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace StudentSpec
{
    [Serializable]
    public class SpecialsList
    {
        //список специальностей
        public List<Special> list;

        public SpecialsList()
        {

        }

        public SpecialsList(SerializationInfo sInfo, StreamingContext contextArg)
        {
            this.list = (List<Special>)sInfo.GetValue("list", typeof(List<Special>));            
        }

        public void GetObjectData(SerializationInfo sInfo, StreamingContext contextArg)
        {
            sInfo.AddValue("list", this.list);
        }

        //сохранение в xml файл
        public static void SerializeObject(string filename, SpecialsList objToSerialize)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SpecialsList));

            //создаем текстовый поток на запись
            TextWriter writer = new StreamWriter(filename);
            //записываем 
            xmlSerializer.Serialize(writer, objToSerialize);
            writer.Close();
        }
    }


}
