﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StudentSpec
{
    [Serializable]
    public class Groups
    {
        //номер группы
        public int id {get; set;}

        //номер специальности, к которой пренадлежит группа
        public int special { get; set; }
        //наименование группы
        public string name { get; set; }

        //количество студентов в группе
        public int students { get; set; }

        //список студентов в группе
        public List<Student> list;

        public Groups()
        {

        }

        public Groups(SerializationInfo sInfo, StreamingContext contextArg)
        {
            this.id = (int)sInfo.GetValue("id", typeof(int));
            this.special = (int)sInfo.GetValue("special", typeof(int));
            this.name = (string)sInfo.GetValue("name", typeof(string));
            this.students = (int)sInfo.GetValue("students", typeof(int));
            this.list = (List<Student>)sInfo.GetValue("groups", typeof(List<Student>));
        }

        public void GetObjectData(SerializationInfo sInfo, StreamingContext contextArg)
        {
            sInfo.AddValue("id", this.id);
            sInfo.AddValue("special", this.special);
            sInfo.AddValue("name", this.name);
            sInfo.AddValue("students", this.students);
            sInfo.AddValue("list", this.list);
        }
    }
}
