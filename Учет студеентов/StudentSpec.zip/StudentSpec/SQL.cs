﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSpec
{
    class SQL
    {
        //строка подключения
        string sqlConnection = "Data Source=database.db;Version=3;New=True;Compress=True;datetimeformat=CurrentCulture";
        //подключение
        SQLiteConnection sqlite_conn;
        

        public SQL()
        {
            // создаем подключение
            sqlite_conn = new SQLiteConnection(sqlConnection);
            // открываем его
            sqlite_conn.Open();
        }

        public void close()
        {
            //закрытие соединения
            sqlite_conn.Close();
        }

        //перевод даты в строку, для записи в бд
        private string DateTimeSQLite(DateTime datetime)
        {
            string dateTimeFormat = "{0}-{1}-{2} {3}:{4}:{5}.{6}";
            return string.Format(dateTimeFormat, datetime.Year, datetime.Month, datetime.Day, datetime.Hour, datetime.Minute, datetime.Second, datetime.Millisecond);
        }

        public void editStudent(int id, string fio, DateTime birthday, string passport)
        {
            SQLiteCommand sqlite_cmd;


            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "UPDATE student SET fio='" + fio + "', birthday='" + DateTimeSQLite(birthday) +
                "',  passport='" + passport + "' WHERE id=" + id;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();
        }

        

        public int addStudent(string fio, DateTime birthday, string passport)
        {            
            SQLiteDataReader sqlite_datareader;
            SQLiteCommand sqlite_cmd;
            

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "INSERT INTO student (id, fio, birthday, passport, adddate) VALUES (null, '" + fio + "', '" + DateTimeSQLite(birthday) +
                "',  '" + passport + "', '" + DateTimeSQLite(DateTime.Now) + "');";

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();


            sqlite_cmd.CommandText = "SELECT id FROM student ORDER BY id desc LIMIT 1";

            // получаем данные для чтения
            sqlite_datareader = sqlite_cmd.ExecuteReader();

            int id = 0;
            // если есть данные
            if (sqlite_datareader.Read()) 
            {
                id = (int)(Int64)sqlite_datareader["id"];

            }
                       

            return id;
        }

        public void addSpecial(string name, string descr)
        {
            SQLiteCommand sqlite_cmd;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();  

            sqlite_cmd.CommandText = "INSERT INTO special (id, name, descr) VALUES (null, '"+name+"', '"+descr+"');";

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();           

        }

        public void addGroup(string name, int special)
        {
            SQLiteCommand sqlite_cmd;
                      

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "INSERT INTO gr (id, name, special) VALUES (null, '" + name + "', " + special + ");";

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();

        }

        public void addStudentSpec(int student, int group)
        {
            SQLiteCommand sqlite_cmd;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "INSERT INTO studspec (id, student, gr) VALUES (null, " + student + ", " + group + ");";

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();
        }

        public void setStudentSpec(int student, int group)
        {
            SQLiteCommand sqlite_cmd;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "UPDATE studspec SET gr=" + group + " WHERE student=" + student;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();
        }

        public void addHistory(string student, string grs, string grd)
        {
            SQLiteCommand sqlite_cmd;
                       
            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "INSERT INTO history (id, student, grs, grd) VALUES (null, '" + student + "', '" + grs + "', '"+grd+"');";

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();
        }

        public void editGr(int id, string name)
        {
            SQLiteCommand sqlite_cmd;
                       
            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "UPDATE gr SET name='" + name + "' WHERE id=" + id;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();
        }

        public void editSpecial(int id, string name, string descr)
        {
            SQLiteCommand sqlite_cmd;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "UPDATE special SET name='" + name + "', descr='" + descr + "' WHERE id=" + id;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();
        }

        public void deleteGr(int id)
        {
            SQLiteCommand sqlite_cmd;
            
            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "DELETE FROM gr WHERE id=" + id;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();

        }

        public void deleteStudent(int id)
        {
            SQLiteCommand sqlite_cmd;


            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();
            //удаляем студента
            sqlite_cmd.CommandText = "DELETE FROM student WHERE id=" + id;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();
            //удаляем соответствия студент-группа
            sqlite_cmd.CommandText = "DELETE FROM studspec WHERE student=" + id;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();
        }

        public void deleteSpecial(int id)
        {
            SQLiteCommand sqlite_cmd;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "DELETE FROM special WHERE id=" + id;

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();

        }

        //создание базы данных
        public void createScheme()
        {
            SQLiteCommand sqlite_cmd;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "CREATE TABLE if not exists special (id integer primary key, name varchar(100), descr varchar(100));";
            sqlite_cmd.ExecuteNonQuery();

            sqlite_cmd.CommandText = "CREATE TABLE if not exists student (id integer primary key, fio varchar(100), birthday datetime, passport varchar(100), adddate datetime);";
            sqlite_cmd.ExecuteNonQuery();

            sqlite_cmd.CommandText = "CREATE TABLE if not exists gr (id integer primary key, name varchar(100), special integer);";
            sqlite_cmd.ExecuteNonQuery();

            sqlite_cmd.CommandText = "CREATE TABLE if not exists studspec (id integer primary key, student integer, gr integer);";
            sqlite_cmd.ExecuteNonQuery();

            sqlite_cmd.CommandText = "CREATE TABLE if not exists history (id integer primary key, student varchar(100), grs varchar(100), grd varchar(100));";
            sqlite_cmd.ExecuteNonQuery();

        }

        public int getStudentCount(int gr)
        {
            SQLiteCommand sqlite_cmd;
            SQLiteDataReader sqlite_datareader;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "SELECT count(id) as cnt FROM studspec WHERE gr=" + gr;

            // получаем данные для чтения
            sqlite_datareader = sqlite_cmd.ExecuteReader();

            int sum = 0;
            // если есть данные для чтения
            if (sqlite_datareader.Read()) 
            {
                sum = (int)(Int64)sqlite_datareader["cnt"];
                
            }

            return sum;
        }


        public List<Student> getListStudents(int gr, int special)
        {
            List<Student> res = new List<Student>();

            SQLiteCommand sqlite_cmd;
            SQLiteDataReader sqlite_datareader;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            
            sqlite_cmd.CommandText = "SELECT student.id,fio,birthday,passport,adddate FROM student,studspec WHERE studspec.student=student.id AND studspec.gr=" + gr;

            // получаем данные для чтения
            sqlite_datareader = sqlite_cmd.ExecuteReader();

            // пока есть данные для чтения
            while (sqlite_datareader.Read()) 
            {
                Int64 _id = (Int64)sqlite_datareader["id"];
                DateTime bdate = (DateTime)sqlite_datareader["birthday"];
                DateTime adate = (DateTime)sqlite_datareader["adddate"];
                res.Add(new Student
                {
                    id = (int)_id,
                    fio = (string)sqlite_datareader["fio"],
                    pasport = (string)sqlite_datareader["passport"],
                    gr = gr,
                    special = special,
                    birthday = bdate,
                    createDate = adate
                });
            }

            return res;
        }

        public List<Groups> getListGr(int special)
        {
            List<Groups> res = new List<Groups>();

            SQLiteCommand sqlite_cmd;
            SQLiteDataReader sqlite_datareader;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();
                        
            sqlite_cmd.CommandText = "SELECT id,name FROM gr WHERE special=" + special;

            // получаем данные для чтения
            sqlite_datareader = sqlite_cmd.ExecuteReader();

            while (sqlite_datareader.Read()) 
            {
                Int64 _id = (Int64)sqlite_datareader["id"];
                string _name = (string)sqlite_datareader["name"];
                res.Add(new Groups
                {
                    id = (int)_id,
                    name = _name,
                    special = special,
                    students = getStudentCount((int)_id)
                });
            }

            return res;
        }

        public List<Special> getListSpecial()
        {
            List<Special> res = new List<Special>();

            SQLiteCommand sqlite_cmd;
            SQLiteDataReader sqlite_datareader;

            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();
            
            sqlite_cmd.CommandText = "SELECT id,name,descr FROM special";

            // получаем данные для чтения
            sqlite_datareader = sqlite_cmd.ExecuteReader();

            
            while (sqlite_datareader.Read()) 
            {
                Int64 _id = (Int64)sqlite_datareader["id"];
                string _name = (string)sqlite_datareader["name"];
                string _descr = (string)sqlite_datareader["descr"];
                res.Add(new Special{id = (int)_id, 
                                    name = _name,
                                    descr = _descr
                });
            }
            
            return res;
        }

        public void test()
        {
            SQLiteCommand sqlite_cmd;
            SQLiteDataReader sqlite_datareader;


            // создаем новую SQL комманду
            sqlite_cmd = sqlite_conn.CreateCommand();

            sqlite_cmd.CommandText = "CREATE TABLE test (id integer primary key, text varchar(100));";

            sqlite_cmd.ExecuteNonQuery();

            sqlite_cmd.CommandText = "INSERT INTO test (id, text) VALUES (1, 'Test Text 1');";

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();

            sqlite_cmd.CommandText = "INSERT INTO test (id, text) VALUES (2, 'Test Text 2');";

            // выполняем комманду
            sqlite_cmd.ExecuteNonQuery();

            sqlite_cmd.CommandText = "SELECT * FROM test";

            // получаем данные для чтения
            sqlite_datareader = sqlite_cmd.ExecuteReader();

            while (sqlite_datareader.Read()) 
            {
                System.Console.WriteLine(sqlite_datareader["text"]);
            }

        }
    }
}
