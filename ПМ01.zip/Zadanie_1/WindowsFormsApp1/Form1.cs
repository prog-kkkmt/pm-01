﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Save()
        {
            string path = openFileDialog1.FileName;
            StreamWriter sw = new StreamWriter(path);
            sw.Write(richTextBox1.Text);
            sw.Close();
        }

        public void Open()
        {
            richTextBox1.Clear();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(openFileDialog1.FileName);
                richTextBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Open();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s = richTextBox1.Text;
            s = Regex.Replace(s, @"\s+", " ");
            richTextBox1.Text = s;            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
