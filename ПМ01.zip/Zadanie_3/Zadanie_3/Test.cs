﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadanie_3
{
    public partial class Test : Form
    {
        public Test()
        {
            InitializeComponent();
        }

        private void Test_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("Test 1.txt");
            StreamReader sr1 = new StreamReader("Test 2.txt");
            textBox1.Text = sr.ReadToEnd();
            textBox2.Text = sr1.ReadToEnd();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] array = new int[15];
            int[] array1 = new int[15];
            string s = textBox1.Text;
            string s1 = textBox2.Text;
            array = s.Split(' ').Select(int.Parse).ToArray();
            array1 = s1.Split(' ').Select(int.Parse).ToArray();
            int[] array3 = new int[15];
            for (int i = 0; i < 15; i++)
            {
                array3[i] = array[i] - array1[i];
                textBox3.Text += array3[i] + " ";
            }
        }
    }
}
