'''
С клавиатуры вводятся числа a и b, b > a. Найдите сумму факториалов чисел из диапазона [a; b]. Для вычисления факториала реализуйте функцию factorial(n).
Входные данные:
3
7
Выходные данные:
5910
Выполнил: Поддубный Даниил П3-16
Источник: https://stepik.org/courses/67
09.10.2019
'''
def factorial(n):
    res = 1
    for i in range(1, n+1):
        res *= i
    return res

n = int(input())
m = int(input())
sum = 0
for i in range(n, m+1):
        sum += factorial(i)
print(sum)

