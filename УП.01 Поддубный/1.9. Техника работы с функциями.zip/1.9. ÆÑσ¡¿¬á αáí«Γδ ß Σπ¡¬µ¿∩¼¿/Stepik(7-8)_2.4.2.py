'''
Вводится натуральное число n. Для этого числа вычислите n-ое число Фибоначчи и выведите сумму этого числа и его факториала.
Вычисление числа Фибоначчи и факториала вынесите в отдельные функции factorial(n) и fib(n). Считайте первое число Фибоначчи равным единице.
Входные данные:
10
Выходные данные:
3628855
Выполнил: Поддубный Даниил П3-16
Источник: https://stepik.org/courses/67
12.10.2019
'''
def factorial(n):
    res = 1
    for i in range(1, n+1):
        res *= i
    return res

def fib(n):
    res_fib = [1,1]
    while len(res_fib)!= n-2:
        res_fib.append(res_fib[-1] + res_fib[-2])       
    return sum(res_fib)
        
n = int(input())
print(factorial(n) + fib(n)+1)


