import numpy as np
a = np.array([1, 2, 3], float)
a.fill(0)
print(a)
