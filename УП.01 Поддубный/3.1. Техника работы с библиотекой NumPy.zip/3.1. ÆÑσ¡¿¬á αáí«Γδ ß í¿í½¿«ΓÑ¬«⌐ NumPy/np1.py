import numpy as np
a = np.array([1, 4, 5, 8], float)
print(a)
