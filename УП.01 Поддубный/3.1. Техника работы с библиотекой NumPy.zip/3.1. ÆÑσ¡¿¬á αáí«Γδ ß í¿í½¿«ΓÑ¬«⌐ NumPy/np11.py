import numpy as np
a = np.array([1, 4, 3, 8, 9, 2, 3], float)
print(np.median(a))
