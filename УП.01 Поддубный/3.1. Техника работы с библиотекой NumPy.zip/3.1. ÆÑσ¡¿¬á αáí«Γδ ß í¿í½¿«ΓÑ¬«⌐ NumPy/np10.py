import numpy as np
print(np.poly([-1, 1, 1, 10]))
