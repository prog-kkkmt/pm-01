import numpy as np
a = np.array(range(6), float).reshape((2, 3))
print(a.transpose())
