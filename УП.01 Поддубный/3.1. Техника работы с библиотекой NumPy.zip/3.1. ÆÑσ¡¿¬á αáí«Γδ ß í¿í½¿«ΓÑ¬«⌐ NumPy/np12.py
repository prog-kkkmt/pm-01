import numpy as np
print(np.random.rand(5))
