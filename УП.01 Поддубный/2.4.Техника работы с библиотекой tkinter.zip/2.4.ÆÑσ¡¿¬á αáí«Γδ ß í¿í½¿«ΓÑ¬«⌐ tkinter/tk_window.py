from tkinter import Tk, Frame, BOTH
 
class Example(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, background="white")#background определяет цвет виджета Frame   
        self.parent = parent#сохраняем ссылку на родительский виджет
        self.initUI()#делегируем создание пользовательского интерфейса методу initUI()
    
    def initUI(self):
        self.parent.title("Simple")#задаем заголовок окну
        self.pack(fill=BOTH, expand=1)#отвечает за горизонтальное и вертикальное размещение виджетов
        
def main():
    root = Tk()#Корневое окно
    root.geometry("250x150+300+300")#задает размер окна и его расположение на экране
    app = Example(root)#создаем образец класса приложения
    root.mainloop() #Обработка событий 
 
if __name__ == '__main__':
    main()
