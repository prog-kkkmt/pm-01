'''
Дан файл целых чисел. Создать два новых файла, первый из которых содержит
положительные числа из исходного файла (в обратном порядке), а второй —
отрицательные (также в обратном порядке). Если положительные или отрицательные
числа в исходном файле отсутствуют, то соответствующий результирующий файл
оставить пустым.
Входные данные: number.txt
в файле number.txt: 11 -22 6 13 8 -7 3 -15
Выходные данные:
в файле positive.txt: 3 8 13 6 11
в файле negative.txt: -15 -7 -22 
Выполнил: Поддубный Даниил П3-16
Источник: Задачник Абрамян
'''
file_name = input('Введите имя файла: ')
arr = []
f = open(file_name, "r")
for line in f:
        arr.extend(line.split(" "))

for item in arr:
    arr[arr.index(item)] = int(item)

print(arr)
arr.reverse()
f.close()
f = open("positive.txt", "w")
f1 = open("negative.txt", "w")

for i in arr:
    if (i >= 0):
        f.write(str(i) + " ")
    else:
        f1.write(str(i) + " ")

f.close()
f1.close()
