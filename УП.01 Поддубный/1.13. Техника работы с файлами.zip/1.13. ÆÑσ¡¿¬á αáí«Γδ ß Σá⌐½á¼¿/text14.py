"""
Text14
Дан непустой файл.
Удалить последнюю строку
Выполнил: Поддубный Даниил П3-16
Источник: задачник Абрамяна
"""
fname = 'text14.txt'
with open(fname,'r') as f:
    line = f.readlines()
with open(fname,'w') as f:
    for i in range(len(line)-1):
        f.write(line[i]) 
print('done')
