'''
Дан файл целых чисел. Найти количество содержащихся в нем серий
(то есть наборов последовательно расположенных одинаковых элементов).
Например, для файла с элементами 1, 5, 5, 5, 4, 4, 5 результат равен 4.
Входные данные: 1 5 5 5 2 3 3 4 5 4 3 3 3
Выходные данные: 8
Выполнил: Поддубный Даниил П3-16
Источник: Задачник Абрамян
'''
file_name = input('Введите имя файла: ')
arr = []
item_last = 0
count = 0

f = open(file_name, "r")

for line in f:
        arr.extend(line.split(" "))

for item in arr:
    arr[arr.index(item)] = int(item)
    if item != item_last:
        count += 1
    item_last = item
print(count)

f.close()

