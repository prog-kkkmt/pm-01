class Shark:    
    def swim(self):
        print("The shark is swimming.")
    def be_awesome(self):
        print("The shark is being awesome.")
        
def main():
    sammy = Shark()
    sammy.swim()
    sammy.be_awesome()

if __name__ == "__main__":
    main()
