from tkinter import *

class Person:
    name = ""
    data = ""
    time = ""

def CheckDate(s, dn, dk): #функция проверки попадания введенной даты в промежуток
    date = [int(x) for x in s.split(".")]
    b = 0
    if dn[2] == dk[2]:
        if dn[1] < date[1] < dk[1]:
            b = 1
        elif (dn[1] == date[1] == dk[1] and (dn[0] <= date[0] <= dk[0])):
              b = 1
        elif (dn[1] == date[1] and date[1] != dk[1] and dn[0] <= date[0]):
              b = 1
        elif (dk[1] == date[1] and date[1] != dn[1] and date[0] <= dk[0]):
              b = 1
    elif dn[2] != dk[2]:
        if dn[2] < date[2] < dk[2]:
            b = 1
        elif (date[2] == dn[2] and date[1] > dn[1]):
            b = 1
        elif (date[2] == dn[2] and date[1] == dn[1] and date[0] >= dn[0]):
            b = 1
        elif (date[2] == dk[2] and date[1] < dk[1]):
            b = 1
        elif (date[2] == dk[2] and date[1] == dk[1] and date[0] <= dk[0]):
            b = 1
    return b

def click_btn1(): #функция, которая выполняется при нажатии на первую кнопку
    win1 = Tk()
    win1.title("Выбор диапазона дат")
    win1.geometry('400x175')
    lbl1 = Label(win1, text="Введите ограничения по дате (формат dd.mm.yyyy), в рамках \nкоторой вы хотите увидеть информацию об опоздавших")
    lbl1.pack()
    lbl2 = Label(win1, text="Введите начальную дату:")
    lbl2.pack()
    txt1 = Entry(win1, width=70)
    txt1.pack()
    lbl3 = Label(win1, text="Введите конечную дату:")
    lbl3.pack()
    txt2 = Entry(win1,width=70)
    txt2.pack()
    def click_Ok(): #функция, которая выполняется при нажатии на кнопку "OK"
        late = {}
        datn = txt1.get()
        datk = txt2.get()
        datn = [int(x) for x in datn.split(".")]
        datk = [int(x) for x in datk.split(".")]
        file = open('DataStudent.txt','r')
        students = file.read().split("\n")
        file.close()
        for x in students:
            x = x.split(" ")
            student = Person()
            student.date = x[0]
            student.name = x[1]
            student.time = x[2].split(":")
            student.time[0], student.time[1] = int(student.time[0]), int(student.time[1])
            if CheckDate(student.date, datn, datk) == 1:
                if (student.time[0] == 9 and student.time[1] > 0 or student.time[0] > 9):
                    if student.name in late:
                        late[student.name] = [late[student.name][0] + (student.time[0] - 9) * 60 + student.time[1], late[student.name][1] + 1]
                    else:
                        late[student.name] = [(student.time[0] - 9) * 60 + student.time[1], 1]
        f = open('DataLateStudent.txt', 'w')
        b = 0
        for x in late:
            b = b + 1
            if b == 1:
                f.write(str(x) + ' ' + str(late[x][0]) + ' ' + str(late[x][1]))
            else:
                f.write('\n' + str(x) + ' ' + str(late[x][0]) + ' ' + str(late[x][1]))
        f.close()
        win1.destroy()
        win2 = Tk()
        win2.title("Уведомление")
        win2.geometry('300x80')
        lbl = Label(win2, text = "Список опоздавших\nуспешно добавлен\nв текстовый файл DataLateStudent\nв текущей директории")
        lbl.pack()
    Ok = Button(win1, text="OK", command = click_Ok)
    Ok.pack()

def click_btn2(): #функция, которая выполняется при нажатии на вторую кнопку
    win1 = Tk()
    win1.title("Заполнение информации")
    win1.geometry('400x200')
    lbl1 = Label(win1, text="Введите дату появления студента:")
    lbl1.pack()
    txt1 = Entry(win1, width=70)
    txt1.pack()
    lbl2 = Label(win1, text="Введите фамилию студента:")
    lbl2.pack()
    txt2 = Entry(win1, width=70)
    txt2.pack()
    lbl3 = Label(win1, text="Введите время появления студента:")
    lbl3.pack()
    txt3 = Entry(win1, width=70)
    txt3.pack()
    def click_Ok(): #функция, которая выполняется при нажатии на кнопку "OK"
        f = open('DataStudent.txt', 'a')
        f.write('\n' + str(txt1.get()) + ' ' + str(txt2.get()) + ' ' + str(txt3.get()))
        f.close()
        win1.destroy()
        win2 = Tk()
        win2.title("Уведомление")
        win2.geometry('300x80')
        lbl = Label(win2, text = "Информация о появлении студента\nуспешно добавлена\nв текстовый файл DataStudent\nв текущей директории")
        lbl.pack()
    Ok = Button(win1, text="OK", command = click_Ok)
    Ok.pack()

def click_btn3(): #функция, которая выполняется при нажатии на третью кнопку
    win = Tk()
    win.title("Список опоздавших")
    win.geometry('400x200')
    file = open('DataLateStudent.txt','r')
    students = file.read()
    file.close()
    lbl1 = Label(win, text = "Фамилия студента / Время позданий (в мин) / Кол-во опозданий")
    lbl1.pack()
    lbl2 = Label(win, text=students)
    lbl2.pack()
    
def click_btn4(): #функция, которая выполняется при нажатии на четвертую кнопку
    win = Tk()
    win.title("Наибольшее количество опозданий")
    win.geometry('400x175')
    lst = []
    Text = ""
    file = open('DataLateStudent.txt', 'r')
    students = file.read().split("\n")
    file.close()
    max_count = 0
    for student in students:
        student = student.split(" ")
        if (int(student[2])) > (int(max_count)):
            max_count = student[2]
    for student in students:
        student = student.split(" ")
        if student[2] == max_count:
            lst.append(student)
    for student in lst:
        Text = Text + student[0] + " " + student[1] + " " + student[2] + "\n"
    lbl1 = Label(win, text = "Фамилия студента / Время позданий (в мин) / Кол-во опозданий")
    lbl1.pack()
    lbl2 = Label(win, text = Text)
    lbl2.pack()

def click_btn5(): #функция, которая выполняется при нажатии на пятую кнопку
    win = Tk()
    win.title("Наибольшее время опозданий")
    win.geometry('400x175')
    lst = []
    Text = ""
    file = open('DataLateStudent.txt', 'r')
    students = file.read().split("\n")
    file.close()
    max_time = 0
    for student in students:
        student = student.split(" ")
        if (int(student[1])) > (int(max_time)):
            max_time = student[1]
    for student in students:
        student = student.split(" ")
        if student[1] == max_time:
            lst.append(student)
    for student in lst:
        Text = Text + student[0] + " " + student[1] + " " + student[2] + "\n"
    lbl1 = Label(win, text = "Ф.И.О студента / Время позданий (в мин) / Кол-во опозданий")
    lbl1.pack()
    lbl2 = Label(win, text = Text)
    lbl2.pack()
    
window = Tk() #создание окна с кнопками
window.title("Журнал посещений")
window.geometry('290x219')    
btn1 = Button(window, text="Записать информацию о посещении", width = "40", pady = "10", background = "lime", command = click_btn1) 
btn1.pack()
btn2 = Button(window, text="Добавить информацию о появлении студента", width = "40", pady = "10", background = "yellow", command = click_btn2) 
btn2.pack()
btn3 = Button(window, text="Вывести список опоздавших", width = "40", pady = "10", background = "tan", command = click_btn3)
btn3.pack()
btn4 = Button(window, text="Студент с наибольшим количеством опозданий", width = "40", pady = "10", background = "pink", command = click_btn4) 
btn4.pack()
btn5 = Button(window, text="Студент с наибольшим временем опозданий", width = "40", pady = "10", background = "orchid", command = click_btn5)
btn5.pack()
window.mainloop()
