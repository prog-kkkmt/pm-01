def CheckDate(s, dn, dk): #функция проверки попадания введенной даты в промежуток
    date = [int(x) for x in s.split(".")]
    b = 0
    if dn[2] == dk[2]:
        if dn[1] < date[1] < dk[1]:
            b = 1
        elif (dn[1] == date[1] == dk[1] and (dn[0] <= date[0] <= dk[0])):
              b = 1
        elif (dn[1] == date[1] and date[1] != dk[1] and dn[0] <= date[0]):
              b = 1
        elif (dk[1] == date[1] and date[1] != dn[1] and date[0] <= dk[0]):
              b = 1
    elif dn[2] != dk[2]:
        if dn[2] < date[2] < dk[2]:
            b = 1
        elif (date[2] == dn[2] and date[1] > dn[1]):
            b = 1
        elif (date[2] == dn[2] and date[1] == dn[1] and date[0] >= dn[0]):
            b = 1
        elif (date[2] == dk[2] and date[1] < dk[1]):
            b = 1
        elif (date[2] == dk[2] and date[1] == dk[1] and date[0] <= dk[0]):
            b = 1
    return b

late = {}
print("Введите ограничения по дате (формат d.m.y):")
datn = input() #ввод начальной даты
datk = input() #ввод конечной даты
datn = [int(x) for x in datn.split(".")]
datk = [int(x) for x in datk.split(".")]
print("Выберите формат ввода данных (0 - с консоли, 1 - из файла): ")
choice = input()
while (choice != '1' and choice != '0'):
    choice = input()
if choice == '0':
    student = input() #входные данные о студентах
    while student != '.':
        student = student.split()
        surn, time = student[1], student[2].split(":")
        time[0], time[1] = int(time[0]), int(time[1])
        if CheckDate(student[0], datn, datk) == 1:
            if (time[0] == 9 and time[1] > 0 or time[0] > 9):
                if surn in late:
                    late[surn] = [late[surn][0] + (time[0] - 9) * 60 + time[1], late[surn][1] + 1]
                else:
                    late[surn] = [(time[0] - 9) * 60 + time[1], 1]
        student = input()
else:
    file = open('DataStudent.txt','r')
    students = file.read().split("\n")
    for student in students:
        student = student.split()
        surn, time = student[1], student[2].split(":")
        time[0], time[1] = int(time[0]), int(time[1])
        if CheckDate(student[0], datn, datk) == 1:
            if (time[0] == 9 and time[1] > 0 or time[0] > 9):
                if surn in late:
                    late[surn] = [late[surn][0] + (time[0] - 9) * 60 + time[1], late[surn][1] + 1]
                else:
                    late[surn] = [(time[0] - 9) * 60 + time[1], 1]
f = open('myfile.txt', 'w')
for x in late:
    f.write(str(x) + ' ' + str(late[x][0]) + ' ' + str(late[x][1]) + ' \n')
f.close()
