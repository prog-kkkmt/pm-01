import sys
from PyQt5.QtWidgets import *
app = QApplication([])
w = QWidget()
w.setWindowTitle("Тест4")
grid = QGridLayout(w)
grid.addWidget(QPushButton("Кнопка1"),0,0)
grid.addWidget(QPushButton("Кнопка2"),0,1)
grid.addWidget(QPushButton("Кнопка3"),1,0)
grid.addWidget(QPushButton("Кнопка4"),1,1)
w.show()
sys.exit(app.exec_())
